/* 
 * thread library function prototypes
 */

void t_init();
void t_shutdown();
int t_create(void (*func)(int), int thr_id, int pri);
void t_terminate();
void t_yield();