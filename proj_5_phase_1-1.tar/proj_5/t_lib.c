/*
Wei Zhang & Siyu Xu
login id: zwwpaul, siyuxu
May/3/2019
*/


#include "t_lib.h"
#include <ucontext.h>

/*
Linked list acts as a queue
*/
tcb *running= NULL;
tcb *ready= NULL;
tcb *main_w= NULL;

/*
Place the object at the end of ready
and first object in ready queue doing execution
*/
void t_yield()
{
  if(ready==NULL){
    return;
  }
  tcb *temp= running;
  running = ready;
  tcb *ready_head= ready;
  if(ready_head != NULL){ 
    while(ready_head->next != NULL){
      ready_head =ready_head -> next;
    }
  }
  ready_head->next = temp;
  ready = ready-> next;
  running -> next =NULL;
  swapcontext((temp->thread_context), (running->thread_context));
}

/* Initialize the thread library 
by setting up the "running" and the "ready" queues,
creating TCB of the "main" thread, and inserting it into the running queue. */
void t_init()
{
  // printf("initializing\n");
  main_w = (tcb*)malloc(sizeof(tcb));
  //To set up the context
  main_w -> thread_id=0;
  main_w -> thread_priority=0;
  main_w -> next= NULL;
  ucontext_t *uc = (ucontext_t *) malloc(sizeof(ucontext_t));
  getcontext(uc); 
  main_w ->thread_context=uc;
  running = main_w;
  ready= NULL;
}

/*
Create new thread with given agruments
After new tcb is created, adds it at the end of the ready queue
*/
int t_create(void (*fct)(int), int id, int pri)
{
  size_t sz = 0x10000;
  tcb * newtcb;
  tcb * temp =ready;
  newtcb = (tcb*)malloc(sizeof(tcb));
  newtcb->thread_id= id;
  newtcb->thread_priority=pri;
  newtcb->next= NULL;
  ucontext_t *uc = (ucontext_t *) malloc(sizeof(ucontext_t));
  getcontext(uc);
  uc->uc_stack.ss_sp = malloc(sz);
  uc->uc_stack.ss_size = sz;
  uc->uc_stack.ss_flags = 0;
  uc->uc_link = (main_w->thread_context); 
  makecontext(uc, (void (*)(void)) fct, pri, id);
  newtcb->thread_context=uc;
  // printf("Thread [%d] is being created!\n", newtcb->thread_id);
  if(ready== NULL){
    ready=newtcb;
  }
  else{
    while(temp->next !=NULL){
      temp= temp->next;
    }
    temp->next=newtcb;
  }
return 0;
}

/* 
Shut down the thread library by freeing all the dynamically allocated memory.
 */
void t_shutdown(){
  tcb * temp;
  while(running!= NULL){
    // printf("Location: Running queue\n");
    temp= running -> next;
    free(running->thread_context->uc_stack.ss_sp);
		free(running->thread_context);
		free(running);
    running = temp;
  }

  while(ready!=NULL){
    // printf("Location: Ready queue\n");
    temp= ready -> next;
    free(ready->thread_context->uc_stack.ss_sp);
		free(ready->thread_context);
		free(ready);
    ready = temp;
  }
}

/*
This function is to terminate the calling thread by removing and freeing tcb from running queue 
Resuming execution the thread in the head of the ready queue
*/
void t_terminate(){
  if(ready==NULL){
    t_shutdown();
  }
  else{
   tcb * tmp = running;
  //  printf("Terminating thread [%d]\n", tmp->thread_id);
   running = ready;
   if (ready != NULL) {
    ready = ready->next;
   }
   running->next = NULL;
   free(tmp->thread_context->uc_stack.ss_sp);
   free(tmp->thread_context);
   free(tmp);
   if(running){
    setcontext((running->thread_context));
  }
  }
}
