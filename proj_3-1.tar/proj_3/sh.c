/*
 * Siyu Xu, Wei Zhang
 * CISC 361
 * 4/16/2019
 * Project 3
 */

#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>
#include "sh.h"
#include <glob.h>
#include <sys/time.h>
#include <utmpx.h>
#include <time.h>
#include <pthread.h>
pid_t cpid;
pthread_mutex_t mutex_Users;
struct utmpx *up;
 struct user *userfirst = NULL;
struct mail *mailfirst = NULL;
struct ipc *phead = NULL;
/* function that starts the shell
 * argc: argument count
 * argv: the array of arguments given
 * envp: the array of ponters to environment variables
 */
int sh( int argc, char **argv, char **envp)
{
  //Setting up variables needed for the shell to function
  char * prompt = calloc(PROMPTMAX, sizeof(char));
  char * prefix = "";
  char *commandline = calloc(MAX_CANON, sizeof(char));
  char *command, *arg, *commandpath, *p, *pwd, *owd;
  char **args = calloc(MAXARGS, sizeof(char*));
  int uid, i, status, argsct, go = 1;
  struct passwd *password_entry;
  char *homedir;
  pthread_t watchingUser;
  int counter=0;
  int noclobber=0;
  struct pathelement *pathlist;
  int count;
  char *token;
  struct prev_cmd* head = NULL;
  struct alias* alist = NULL;
  int space;
  int valid;
  int background=0;
  uid = getuid();
  password_entry = getpwuid(uid);               /* get passwd info */
  homedir = password_entry->pw_dir;		/* Home directory to start
						  out with*/
 
  // store the current working directory  
  if ( (pwd = getcwd(NULL, PATH_MAX+1)) == NULL )
  {
    perror("getcwd");
    exit(2);
  }
  owd = calloc(strlen(pwd) + 1, sizeof(char));
  memcpy(owd, pwd, strlen(pwd));

  // Set up the initial prompt
  prompt[0] = ' '; prompt[1] = '['; prompt[2] = '\0';

  strcat(prompt, pwd);
  prompt[strlen(prompt)+3] = '\0';
  prompt[strlen(prompt)] = ']';
  prompt[strlen(prompt)] = '>';
  prompt[strlen(prompt)] = ' ';

  /* Put PATH into a linked list */
  pathlist = get_path();

  while ( go )
  {
    int ipc_flag = 0;
    /* print your prompt */
    valid = 1;
    printf("%s%s", prefix, prompt); 
    
    // Read in command line
	if(fgets(commandline, MAX_CANON, stdin) == NULL){
		commandline[0] = '\n';
		commandline[1] = '\0';
		valid = 0;
		printf("\n");
	}
	int space = 1;
	
	// Remove newline character from end of input
	if (strlen(commandline) > 1){
		commandline[strlen(commandline) - 1] = '\0';
	}
	else {
		valid = 0;
	}	
	
	// Check command for special cases
	for(i = 0; i < strlen(commandline); i++){
		if(commandline[i] != ' '){
			space = 0;
		}
	}
	if (space){
		commandline[strlen(commandline)-1] = '\n';
		valid = 0;
	}	
	
	// Parse the command line to separate the arguments
	count = 1;
	args[0] = strtok(commandline, " ");
	while((arg=strtok(NULL, " ")) != NULL){
		args[count] = arg;
		count++;
	}
   	args[count] = NULL;
	argsct = count;

	if(argsct>1){
		if(strcmp(args[argsct-1], "&") == 0){
			background=1;
            args[argsct-1] = NULL;
		}else{
			background=0;
		}
	}

	// Check if command is an alias
	struct alias* curr = alist;
	int found = 0;
	int done = 0;
	if(argsct == 1){
		while(curr != NULL && !done){
			found = 0;
			if(strcmp(curr->name, args[0]) == 0){
				strcpy(commandline, curr->cmd);
				found = 1;
				count = 1;
				args[0] = strtok(commandline, " ");
				while((arg=strtok(NULL, " ")) != NULL){
					args[count] = arg;
					count++;
				}
   				args[count] = NULL;
				argsct = count;
				if(curr->used == 1){
					args[0] = "\n\0";
					printf("Alias Loop\n");
					done = 1;
				}
				curr->used = 1;
			}
			curr = curr->next;
			if(found) {
				curr = alist;
			}
		}
	}
	
	// Reset (used) aspect of each alias struct
	curr = alist;
	while(curr!=NULL){
		curr->used = 0;
		curr=curr->next;
	}
//---------------------------------------------IPC---------------------------------------------
      int pipe_index = -1;
      //To find the index of the signal
      for(int j = 0; j < argsct; j++){
          if(args[j] != NULL && strcmp(args[j], "|") == 0){
              pipe_index = j;
          }
      }
      if(pipe_index == 0 || pipe_index == argsct){
          pipe_index = 0;
      }
      char **leftargs = calloc(MAXARGS, sizeof(char*));
      char **rightargs = calloc(MAXARGS, sizeof(char*));
      pid_t leftchild = -1, rightchild = -1;
      if(pipe_index != 0 && pipe_index != -1){
          
          // Separate the arguement into two parts: Left and Right
          for(int j = 0; j < pipe_index; j++){
              leftargs[j] = malloc(1 + (sizeof(char) * strlen(args[j])));
              strcpy(leftargs[j],args[j]);
          }
          int k = 0;
          for(int j = pipe_index + 1; j < argsct; j++){
              rightargs[k] = malloc(1 + (sizeof(char) * strlen(args[j])));
              strcpy(rightargs[k],args[j]);
              k++;
          }
          
          //To create pipes for IPC
          int ipc[2];
          if(pipe(ipc) != 0){
              perror("Error : '|' ");
              exit(0);
          }
          
          //Left part
          leftchild = fork();
          if(leftchild == 0){
              args = leftargs;
              go = 0;
              close(STDOUT_FILENO);
              dup(ipc[1]);
              close(ipc[0]);
          }
          else{
              // Right part
              rightchild = fork();
              if(rightchild == 0){
                  args = rightargs;
                  command = NULL;
                  free(command);
                  command = malloc(1 + (sizeof(char) * strlen(args[0])));
                  strcpy(command, args[0]);
                  go = 0;
                  close(STDIN_FILENO);
                  dup(ipc[0]);
                  close(ipc[1]);
              }
              else{
                  close(ipc[0]);
                  close(ipc[1]);
                  struct ipc *tmp;
                  tmp = malloc(sizeof(struct ipc));
                  tmp->pid = leftchild;
                  tmp->next = NULL;
                  if(phead == NULL){
                      phead = tmp;
                  }
                  else{
                      tmp->next = phead;
                      phead = tmp;
                  }
                  waitpid(rightchild, NULL, 0);
              }
          }
      }
//---------------------------------------------IPC---------------------------------------------
      
//------------- Check for each Built-In commands and External commands-----------------------------
	command = args[0];
	if(strcmp(command, "exit") == 0){
		// Exit the shell
		printf("Executing built-in exit\n");
		exit(0);
	}
    else if(strcmp(args[0],"noclobber") == 0){
        if(argsct > 1){
            fprintf(stderr, "Noclobber: too many arguments.\n");
        }
        //reset noclobber to opposite value than before
        if(noclobber == 1){
            noclobber = 0;
            printf("Noclobber is now off\n");
        }
        else{
            noclobber = 1;
            printf("Noclobber is now on\n");
        }
    }
	else if(strcmp(command, "watchuser") == 0){
		if(argsct<2){
			printf("watchuser: Too few arguments.\n");
		}else if(argsct==2){
			if(strcmp(args[1], "-l") == 0){
				if(userfirst !=NULL){
					printusers();
				}else{
					printf("No users are being watched.\n");
					fflush(stdout);
				}
			}
            else{
                printf("Watching user %s\n", args[1]);
                char* user = (char *)malloc(strlen(args[1]));
                strcpy(user, args[1]);
                pthread_mutex_lock(&mutex_Users);
                userfirst = userAdd(userfirst, user);
                pthread_mutex_unlock(&mutex_Users);
                
                if(counter == 0) {
                    pthread_create(&watchingUser, NULL, watchuser_thread, NULL);
                    counter = 1;
                }
			}
		}
	}
/*
Extra_Credits: To use this feature, you have try this test case below
            sleep 20 &   //run sleep external command at the background, it will also show the pid
            fg <pid>     // it will get into background process.
*/
    else if(strcmp(command, "fg") == 0) {
        printf("Executing build-in fg\n");
        /* No arguments, bring a default process into foreground */
        if(argsct == 1) {
            kill(0, SIGCONT);
            wait(NULL);
        }
        /* One argument, bring the process with pid into foreground */
        else if(argsct == 2) {
            if(atoi(args[1])) {
                kill(atoi(args[1]), SIGCONT);
                waitpid(atoi(args[1]), NULL, 0);
            } else {
                fprintf(stderr, "ERROR!\n");
            }
        } else {
            fprintf(stderr, "ERROR!\n");
        }
    }
    else if(strcmp(command, "watchmail") == 0){
        if(argsct<2){
            printf("watchmail: Too few arguments.\n");
        }
        else if(argsct==2){
            printf("watchingmail %s\n", args[1]);
            struct stat buff;
            int existnumber = stat(args[1],&buff);
            if (existnumber==0){
                pthread_t thread_id;
                char* filepath = (char *)malloc(strlen(args[1]));
                strcpy(filepath, args[1]);
                pthread_create(&thread_id, NULL, watchmail_thread, (void *)filepath);
                mailfirst = mailAdd(mailfirst, filepath, thread_id);
                
            }else{
                printf("%s does not exist\n",args[1]);
            }
        }
        else if(argsct==3){
            if(strcmp(args[2], "off") == 0) {
                printf("watchmail for %s off\n",args[1]);
                mailfirst = mailRemove(mailfirst,args[1]);
            }else{
                printf("%s does not exist\n",args[1]);
            }
        }else {
            printf("watchmail: Too many arguments.\n");
        }
    }
	else if(strcmp(command, "which") == 0){
		// Finds first alias or file in path directory that 
		// matches the command
		printf("Executing built-in which\n");
		if(argsct == 1){
			fprintf(stderr, "which: Too few arguments.\n");
		}
		else{
			// Checks for wildcard arguments
			glob_t globber;
			int i;
			for(i = 1; i < argsct; i++){
				int globreturn = glob(args[i], 0, NULL, &globber);
				if(globreturn == GLOB_NOSPACE){
					printf("glob: Runnning out of memory.\n");
				}
				else if(globreturn == GLOB_ABORTED){
					printf("glob: Read error.\n");
				}
				else{
				
					if(globber.gl_pathv != NULL){
						which(globber.gl_pathv[0], pathlist, alist);
					}
					else {
						which(args[i], pathlist, alist);
					}
				}
			}
		}
	}
	else{

        // If the command is not an alias or built in function, find it
        // in the path
	int found = 0;
	int status;
	char* toexec = malloc(MAX_CANON*sizeof(char));
	if(access(args[0], X_OK) == 0){
		found = 1;
		strcpy(toexec, args[0]);
	}
	else{
		struct pathelement* curr = pathlist;
		char *tmp = malloc(MAX_CANON*sizeof(char));
		
		while(curr!=NULL & !found){
			snprintf(tmp,MAX_CANON,"%s/%s", curr->element, args[0]);
			if(access(tmp, X_OK)==0){
				toexec = tmp;
				found = 1;		
			}
			curr=curr->next;
		}
	}

	// If the command if found in the path, execute it as a child process
	if(found){

		// Create a child process
		cpid = fork();
		struct itimerval timer;
		if(cpid == 0){
//-------------------------------------Redirect---------------------------------------------------------
            int redir = redirection(args,pwd,noclobber);
            if(redir == 0){
                kill(getpid(),SIGKILL);
            }
            //if redirection is found
            else{
                //reset args as appropriate so we can exec
                char *cur_arg = args[0];
                int i = 0;
                while (cur_arg != NULL){
                    if ((strcmp(cur_arg, ">") == 0) || (strcmp(cur_arg, ">&") == 0) || (strcmp(cur_arg, ">>") == 0) || (strcmp(cur_arg, ">>&") == 0) || (strcmp(cur_arg, "<") == 0)){
                        args[i] = NULL;
                        args[i+1] = NULL;
                        break;
                    }
                    else{
                        i++;
                        cur_arg = args[i];
                    }
                }
            }
//-------------------------------------Redirect---------------------------------------------------------

            // Child process executes command
            if(background){
                printf("\nExecuting %s\n", toexec);
                printf("starting background -- job ID: %d\n", cpid);
                //args[argc-2] = NULL;
                execve(toexec, args, envp);
//                reset_redirection(fileid, redir_type);
            }else{
                printf("\nExecuting %s\n", toexec);
                execve(toexec, args, envp);
//                reset_redirection(fileid, redir_type);
            }
            exit(0);
        }
		else if(cpid == -1){
			perror(NULL);
		}
		else {
			// Parent process (shell) times child process 
			if(argc > 1){
				timer.it_value.tv_sec = atoi(argv[1]);
				timer.it_interval.tv_sec = 0;
				if(setitimer(ITIMER_REAL, &timer, NULL)==-1){
					perror(NULL);
				}
			}

            // Parent process (shell) waits for child process to terminate
            if(background){
                printf("starting background -- job ID: %d\n", cpid);
            }else{
                waitpid(pid, &status, WNOHANG);
            }
			
			// Disable timer after child process terminates
			if(argc > 1){
				timer.it_value.tv_sec = 0;
				if(setitimer(ITIMER_REAL, &timer, NULL)==-1){
					perror(NULL);
				}
			}

			// Return non-normal exit status from child
			if(WIFEXITED(status)){
				if(WEXITSTATUS(status) != 0){
					printf("child exited with status: %d\n", WEXITSTATUS(status));
				}
			}
		}
	}

	// Give error if command not found
        else if (valid){
          fprintf(stderr, "%s: Command not found.\n", args[0]);
        }
      }
  }
  return 0;
} /* sh() */

/* function call for 'which' command
 * command: the command that you're checking
 * pathlist: the path list data structure
 * alist: the alias data structure
 */
char *which(char *command, struct pathelement *pathlist, struct alias *alist )
{
	// Set up path linked list variables
	struct pathelement *curr = pathlist;
	char *path = malloc(MAX_CANON*(sizeof(char)));
	int found = 0;
	

	// Search aliases for command
	struct alias* curra = alist;
	while(curra != NULL){
		if(strcmp(curra->name, command)==0){
			printf("%s:\t aliased to %s\n", curra->name, curra->cmd);
			found = 1;
		}
		curra=curra->next;
	}

	// Search path for command
	while(curr != NULL && !found){
		strcpy(path, curr->element);
		path[strlen(path)+1] = '\0';
		path[strlen(path)] = '/';
		strcat(path, command);
		if(access(path, F_OK) == 0){
			printf("%s\n", path);
			found = 1;
		}
		curr = curr->next;
	}
    
	// Print error if command not found
	if (!found){
		fprintf(stderr, "%s: command not found\n", command);
		return NULL;
	}

} /* which() */


//-------------------------------------Watchuser---------------------------------------------------------
void *watchuser_thread(void *arg){
    struct utmpx *up;
    int counter1=0;
    int flag_once=0;
    while(1){
        setutxent();
        while((up = getutxent())){
            if ( up->ut_type == USER_PROCESS )
            {
                pthread_mutex_lock(&mutex_Users);
                struct user* user = userFind(userfirst, up->ut_user);
                if(user != NULL){
                        printf("\n%s has logged on %s from %s\n", up->ut_user, up->ut_line, up ->ut_host);
                }
                pthread_mutex_unlock(&mutex_Users);
        
        //Extra Credits
            }else if(up->ut_type == DEAD_PROCESS)
            {
                struct user* user2 = userFind(userfirst, up->ut_user);
                if(user2!=NULL){
                    printf("\n%s has logged out %s from %s\n", up->ut_user, up->ut_line, up ->ut_host);
                }
            }
        }
        endutxent();
	//Show the track every 20 seconds.
        sleep(20);
    }
}
void printusers(){
	struct user* currUser = userfirst;
	while(currUser->next != NULL)
	{
		printf("%s, ", currUser->name);
		currUser = currUser->next;
	}
	printf("%s\n", currUser->name);
	fflush(stdout);
}


struct user* userAdd(struct user* h, char* user){
    struct user* curr = h;
    
    if(h != NULL){
        while(curr->next != NULL){
            curr = curr->next;
        }
    }
    struct user* new = (struct user*)malloc(sizeof(struct user));
    new->name = user;
    new->next = NULL;
    new->dead = 0;
    
    strcpy(new->name, user);
    
    if(h != NULL){
        curr->next = new;
    }else{
        h = new;
    }
    return h;
}

struct user* userFind(struct user* h, char* user){
    struct user* curr = h;
    while(curr != NULL){
        if(strcmp(user, curr->name) == 0){
            return curr;
        }
        curr = curr->next;
    }
    return NULL;
}
//-------------------------------------Watchuser---------------------------------------------------------


//-------------------------------------Redirect---------------------------------------------------------
int redirection(char **args, char *cur_dir, int noclobber){
    int i = 0;
    int succ=99;
    char *cur_arg = args[0];
    while (cur_arg != NULL){
        if ((strcmp(cur_arg, ">") == 0) || (strcmp(cur_arg, ">&") == 0) || (strcmp(cur_arg, ">>") == 0) || (strcmp(cur_arg, ">>&") == 0) || (strcmp(cur_arg, "<") == 0)){
            break;
        }
        else{
            i++;
            cur_arg = args[i];
        }
    }
    if(args[i+1] != NULL){
        if (args[i+1][0] != '/'){
            char *tmp = malloc(256);
            strcpy(tmp,cur_dir);
            strcat(tmp,"/");
            strcat(tmp,args[i+1]);
            strcpy(args[i+1],tmp);
        }
        int fileid;
        if(strcmp(cur_arg, ">") == 0){
            printf("Processing redirecting: > \n");
            if(access(args[i+1],F_OK != -1) && (noclobber == 1)){
                printf("Can't overwrite existing file if noclobber is turned on.\n");
                return 0;
            }
            fileid = open(args[i+1], O_CREAT| O_WRONLY| O_TRUNC, S_IRWXU);
            close(1);
            dup(fileid);
            close(fileid);
            return succ;
        }
        
        else if(strcmp(cur_arg, ">&") == 0){
            printf("Processing redirecting: >& \n");
            if(access(args[i+1],F_OK != -1) && (noclobber == 1)){
                printf("Can't overwrite existing file if noclobber is turned on.\n");
                return 0;
            }
            fileid = open(args[i+1], O_CREAT| O_WRONLY| O_TRUNC, S_IRWXU);
            close(1);
            close(2);
            dup(fileid);
            dup(fileid);
            close(fileid);
            return succ;
        }
        
        else if(strcmp(cur_arg, ">>") == 0){
            printf("Processing redirecting: >> \n");
            if(access(args[i+1],F_OK == -1) && (noclobber == 1)){
                printf("Can't overwrite or create files with >> if noclobber is turned on.\n");
                return 0;
            }
            if (access(args[i+1],F_OK) != -1){
                fileid = open(args[i+1], O_RDWR | O_APPEND, S_IRUSR | S_IWUSR);
            }
            else{
                fileid = open(args[i+1], O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
            }
            close(1);
            dup(fileid);
            close(fileid);
            return succ;
        }
        
        else if(strcmp(cur_arg, ">>&") == 0){
            printf("Processing redirecting: >>& \n");
            if(access(args[i+1],F_OK == -1) && (noclobber == 1)){
                printf("Can't overwrite or create files with >>& if noclobber is turned on.\n");
                return 0;
            }
            if (access(args[i+1],F_OK) != -1){
                fileid = open(args[i+1], O_RDWR | O_APPEND, S_IRUSR | S_IWUSR);
            }
            else{
                fileid = open(args[i+1], O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
            }
            close(1);
            close(2);
            dup(fileid);
            dup(fileid);
            close(fileid);
            return succ;
        }
        
        else if(strcmp(cur_arg, "<") == 0){
            printf("Processing redirecting: < \n");
            fileid = open(args[i+1], O_RDWR | S_IRUSR | S_IWUSR);
            close(0);
            dup(fileid);
            close(fileid);
            return succ;
        }
        fileid = open("/dev/tty",O_WRONLY);
    }
    return succ;
}
//-------------------------------------Redirect---------------------------------------------------------

//-------------------------------------Watchmail---------------------------------------------------------
struct mail* mailAdd(struct mail* head, char* filepath, pthread_t id){
    struct mail* current = head;
    
    
    if(head != NULL){
        while(current->next != NULL){
            current = current->next;
        }
    }
    
    struct mail* new = (struct mail*)malloc(sizeof(struct mail));
    new->filepath = filepath;
    new->next = NULL;
    strcpy(new->filepath, filepath);
    new->thread_id = id;
    if(head != NULL){
        current->next = new;
    }else{
        head = new;
    }
    return head;
}

struct mail* mailRemove(struct mail* head, char* filepath){
    struct mail* current = head;
    if(strcmp(current->filepath, filepath) == 0){
        head = current->next;
        pthread_cancel(current->thread_id);
        pthread_join(current->thread_id, NULL);
        free(current->filepath);
        free(current);
        return head;
    }
    
    while(current!=NULL){
        struct mail* next = current->next;
        
        if(next != NULL){
            if(strcmp(next->filepath, filepath) == 0){
                current->next = next->next;
                pthread_cancel(next->thread_id);
                pthread_join(next->thread_id, NULL);
                free(next->filepath);
                free(next);
                
            }
        }
        current = next;
    }
    return head;
}

void *watchmail_thread(void *arg) {
    
    char* filepath = (char*)arg;
    struct stat stat_path;
    
    stat(filepath, &stat_path);
    long old_size = (long)stat_path.st_size;
    
    time_t curtime;
    while(1) {
        time(&curtime);
        
        stat(filepath, &stat_path);
        if((long)stat_path.st_size != old_size) {
            printf("\a\nBEEP You've Got Mail in %s at time %s\n", filepath, ctime(&curtime));
            fflush(stdout);
            old_size = (long)stat_path.st_size;
        }
        sleep(1);
        
    }
}
//-------------------------------------Watchmail---------------------------------------------------------


