/*
Project 5 Phase 4 
Wei Zhang & Siyu Xu
login id: zwwpaul, siyuxu
May/15/2019

We used the phase 1 as a base for phase 3 which was given by professor.Shen.
And phase 4 is based on phase 3 
*/


#include "t_lib.h"

//Running TCB pointer
struct tcb *running;
//Ready queue pointer
struct Queue *ready;

// Message queue
messageNode* mssgQ;

/**
*@brief Performs a swapcontext() between the calling thread and the next thread in ready queue
*
*@return VOID
*/
void t_yield()
{
	//Declare a temporary tcb pointer for swapping
	struct tcb *tmp;
	
	//Set the currently running tcb to temp
	tmp = running;
	
	//Dequeue the next thread in ready
	struct QNode *new_running = deQueue(ready);

	if(new_running != NULL)
	{
		//Set running to point to TCB of the QNode we just dequeued
		running = new_running->tcb;
		
		free(new_running);
		
		//Enqueue the TCB that is pointed to by temp to back of ready queue
		enQueue(ready, tmp);
		
		//Swapcontext between the TCB we just enqueued and the one running points to
		swapcontext(tmp->thread_context, running->thread_context);
	}
}

/**
*@brief Initializes the Thread Library by creating an empty ready queue and the main TCB
*
*@return VOID
*/
void t_init()
{
	//Initialize the ready queue
	ready = createQueue();
	
	//Allocate memory for the main TCB
	tcb *tmp = (tcb *) malloc(sizeof(struct tcb));
	
	//Set its fields
	tmp->thread_id = 0;
	tmp->thread_priority = 0;
	
	//Allocate memory for the context of the main thread
	ucontext_t *uc;
	uc = (ucontext_t *) malloc(sizeof(ucontext_t));
	
	//Get the context of main
	getcontext(uc);
	
	//Set the thread_context field of tmp
	tmp->thread_context = uc;
	
	//Set running to point to tmp
	running = tmp;
}

/**
*@brief Creates a new thread with given pri, id and fct, adding to end of ready queue
*
*@param *fct: a pointer to a void function to be run by the thread
*
*@param id: an integer signifying the id of the thread to be created
*
*@param pri: an integer signifying the priority of the given thread
*
*@return the id of the created thread
*/
void t_create(void (*fct)(int), int id, int pri)
{
	//Size for stack allocation
	size_t sz = 0x10000;

	//Define a new ucontext and tcb for our new thread
	ucontext_t *uc;
	tcb *new_tcb;
	
	//Allocate space on the heap
	uc = (ucontext_t *) malloc(sizeof(ucontext_t));

	//Grab the current context so we can modify it
	getcontext(uc);

	//Set the new thread context appropriately
	uc->uc_stack.ss_sp = malloc(sz);
	uc->uc_stack.ss_size = sz;
	uc->uc_stack.ss_flags = 0;
	uc->uc_link = running->thread_context; 
	
	//Make the thread context using the ucontext we just set up
	makecontext(uc, (void (*)(void)) fct, 1, id);
	
	//Setup the TCB using the ucontext we just created
	new_tcb = (tcb *) malloc(sizeof(tcb));
	new_tcb->thread_id = id;
	new_tcb->thread_priority = pri;
	new_tcb->thread_context = uc;
	
	//Add the TCB to the back of our queue
	//This simultaneously creates a new QNode with our TCB and adds to the back
	enQueue(ready, new_tcb);
	
	//Return the thread id upon success or errno otherwise
	//Right now we will just return  the thread id always
	//return id;
}

/**
*@brief Frees all memory associated with any structures (TCB, Queue etc)
*
*@return VOID
*/
void t_shutdown()
{
	//Declare a temp TCB, QNode and Queue structure for freeing
	struct tcb *tmp;
	struct QNode *qntmp = ready->front;
	
	//Loop through the ready Queue and free everything associated
	while(qntmp != NULL)
	{
		//Grab the TCB associated with the QNode
		tmp = qntmp->tcb;
		
		//Free the thread context of the TCB and the TCB
		if(tmp->thread_id > 0) {free(tmp->thread_context->uc_stack.ss_sp);}
		free(tmp->thread_context);
		free(tmp);
		
		//Free the QNode
		free(qntmp);
		
		qntmp = qntmp->next;
	}
	
	//Free the TCB associated with whatever thread is pointed to by running
	tmp = running;
	if(tmp->thread_id > 0) {free(tmp->thread_context->uc_stack.ss_sp);}
	free(tmp->thread_context);
	free(tmp);
	
	//Free the Ready Queue itself
	free(ready);
}

/**
*@brief Terminates the calling thread and swaps context to the next thread in running queue
*
*@return VOID
*/
void t_terminate()
{
	//Declare a temporary tcb pointer for swapping
	struct tcb *tmp;
	struct QNode *qntmp;
	
	//Set the currently running tcb to temp
	tmp = running;
	
	//Free the memory associated with the running thread
	free(tmp->thread_context->uc_stack.ss_sp);
	free(tmp->thread_context);
	free(tmp);
	
	//Grab the thread at the head of the queue
	qntmp = deQueue(ready);
	
	//Set running to point to this TCB
	running = qntmp->tcb;
	
	free(qntmp);
	
	//setcontext() to the new running thread
	setcontext(running->thread_context);
}

/**
*@brief Creates a new linked list node to add to the queue of nodes
*
*@param tcb: A Thread control block referencing the thread associated with the node
*
*@return A pointer to the newly created QNode
*/ 
// A utility function to create a new linked list node. 
struct QNode *newNode(tcb *tcb)
{
	//Create a new QNode and allocate space for it
    struct QNode *temp = (struct QNode*)malloc(sizeof(struct QNode)); 
	
	//Set the TCB and next fields
    temp->tcb = tcb; 
    temp->next = NULL; 
	
	//Return the new node
    return temp;  
}

/**
*@brief A utility function that creates an empty Queue and allocates memory for it
*
*@return A pointer to the newly created Queue
*/
struct Queue *createQueue() 
{
	//Allocate memory for a new queue
	struct Queue *q = (struct Queue*)malloc(sizeof(struct Queue)); 
	
	//Set the head and tail pointers to NULL
    q->front = q->rear = NULL; 
	
	//Return the new queue object
    return q; 
}

/**
*@brief Adds a thread control block to the back of the queue
*
*@param *q: A pointer to the queue the user wishes to add to
*
*@param tcb: A Thread control block referencing the thread to add
*
*@return VOID
*/ 
void enQueue(struct Queue *q, tcb *tcb) 
{ 
    //Create a new node to add to the list
    struct QNode *temp = newNode(tcb); 
  
    //Check if the queue is empty, if so front and rear are the same
    if (q->rear == NULL) 
    {
       q->front = q->rear = temp; 
       return; 
    }
  
    //Otherwise add the new node to the end of the queue
    q->rear->next = temp; 
    q->rear = temp; 
}

/**
*@brief Pops a QNode from the front of the queue
*
*@param *q: A pointer to the queue the user wishes to remove from
*
*@return A pointer to the QNode returned
*/ 
struct QNode *deQueue(struct Queue *q) 
{ 
    //If the queue is empty return NULL
    if (q->front == NULL) 
	{
       return NULL; 
	}
  
    //Store previous front and move front one node ahead 
    struct QNode *temp = q->front; 
    q->front = q->front->next; 
  
    //If front becomes NULL, then change rear to NULL as well
    if (q->front == NULL)
	{		
       q->rear = NULL; 
	}
	
	//Return the node we removed
    return temp; 
}


///////////////////////////////////////
//////          Phase3          ///////
///////////////////////////////////////

/* Create a new semaphore pointed to by sp with a count value of sem_count. */
int sem_init(sem_t **sp, int sem_count)
{
    (*sp) = malloc(sizeof(sem_t));
    (*sp)->count = sem_count;
    (*sp)->q = createQueue();
    return 0;
}

/* Current thread does a wait (P) on the specified semaphore. */
void sem_wait(sem_t *sp)
{
    QNode *running_queue;
    tcb *temp;
    sp->count--;
    //swap the content for the currently running thread and the next thread in the queue
    if(sp->count < 0)
    {
        temp = running;
        enQueue(sp->q, temp);
        running_queue = deQueue(ready);
        running = running_queue->tcb;
        swapcontext(temp->thread_context, running->thread_context);
        return;
    }
}

/* Current thread does a signal (V) on the specified semaphore.
 Follow the Mesa semantics (p. 9 of Chapter 30 Condition Variables) where the thread that signals continues,
 and the first waiting (blocked) thread (if there is any) becomes ready. */
void sem_signal(sem_t *sp)
{
    sp->count++;
    if(sp->count <= 0)
    { 
        QNode *ready_head = deQueue(sp->q);
        if(ready_head  == NULL)
        {
           printf("Error! No thread can be switched to!\n");
        }
        enQueue(ready, ready_head->tcb);
        free(ready_head);
        return;
    }
    
}

/* Destroy (free) any state related to specified semaphore. */
void sem_destroy(sem_t **sp)
{
    //Free q node and corresponding information in the structs
    tcb *temp;
    QNode *q = (*sp)->q->front;
    while(q != NULL)
    {
        temp = q->tcb;
        free(temp->thread_context->uc_stack.ss_sp);
        free(temp->thread_context);
        free(temp);
        free(q);
        q = q->next;
    }
    free(*sp);
} 


///////////////////////////////////////
//////          Phase4          ///////
///////////////////////////////////////


// Test06 Passed!
/* Create a mailbox pointed to by mb. */
// Initially set all the attributes in the mbox struct to NULL
int mbox_create(mbox **mb) {
 	mbox* newbox;
	newbox= (mbox *) malloc(sizeof(mbox));
    newbox->msg = NULL;
    newbox->mbox_sem = NULL;
	sem_init(&(newbox)->mbox_sem, 0);
    *mb = newbox;
    return 0;
}

// Test06 Passed!
/* Destroy any state related to the mailbox pointed to by mb. */
// Free all the allocated memories
void mbox_destroy(mbox **mb){
	if((*mb)->msg != NULL){
		messageNode *tmp = (*mb)->msg;
		while(tmp != NULL){
			tmp = tmp->next;
			free((*mb)->msg->message);
			free((*mb)->msg);
			(*mb)->msg = tmp;
		}
	}
	if((*mb)->mbox_sem != NULL)
		sem_destroy(&(*mb)->mbox_sem);
	free((*mb));
}

// Test06 Passed!
/* Deposit message msg of length len into the mailbox pointed to by mb. */
void mbox_deposit(mbox *mb, char *msg, int len) {
	messageNode* mssg;
	messageNode* head;
	
	// Create a new message based on the given structure 
	mssg =(messageNode *) malloc(sizeof(messageNode));
	head = mb->msg;
  	mssg->message = malloc(sizeof(char) * len+1);
	mssg->sender=0;
	mssg->receiver=0;
	mssg->next = NULL;
	mssg->len = len;
  	strncpy(mssg->message,msg,len);
  	if (mb->msg == NULL) {
    	mb->msg = mssg;
  	} else {
    	while (head->next) {
           head = head -> next;
    	}
   		head->next = mssg;
  	}
}


// Test06 Passed!
/* Withdraw the first message from the mailbox pointed to by mb into msg and set the message's length in len accordingly.
 The caller of mbox_withdraw() is responsible for allocating the space in which the received message is stored.
 If there is no message in the mailbox, len is set to 0. */
void mbox_withdraw(mbox *mb, char *msg, int *len)
{
  struct messageNode * head = mb->msg;
  if (head == NULL) {
    len = 0;
  } else {
    strcpy(msg, head->message);
    *len = head->len;
  }

  if (mb->msg != NULL) {
    mb->msg = mb->msg->next;
    free(head -> message);
    free(head);
  }
}




//---------------------------------------------------------------------------//

// Test05 and Test08 passed!
// Senzer-Spicer Test passed!
/* Send a message to the thread whose tid is tid. msg is the pointer to the start of the message, and len specifies the length of the message in bytes.
 In your implementation, all messages are character strings. */
void send(int tid, char *msg, int len)
{
  struct messageNode * mssg;
  mssg = (messageNode *) malloc(sizeof(messageNode));
  struct messageNode * temp;

  // Create a new message based on the given structure 
  mssg->message = malloc(sizeof(char) * len+1);
  strcpy(mssg->message, msg);
  mssg->len = len;
  mssg->receiver = tid;
  mssg->sender = running->thread_id;
  mssg->next = NULL;

  // Place message into the queue
  // If the message queue is NULL, directly put it into queue
  // Otherwise, using while loop to point to the last node of the message queue
  if (mssgQ==NULL) {
    mssgQ = mssg;
  } else {
    temp = mssgQ;
    while (temp->next) {
      temp = temp->next;
    }
    temp->next = mssg;
  }
}

// Test05 and Test08 passed!
// Senzer-Spicer Test passed!
/* Wait for and receive a message from another thread. 
 The caller has to specify the sender's tid in tid, or sets tid to 0 if it intends to receive a message sent by any thread.
 If there is no "matching" message to receive, the calling thread waits (i.e., blocks itself).*/
void receive(int *tid, char *msg, int *len)
{
  struct messageNode * temp = mssgQ;
  //If the queue is equal to NULL, force it to exit the function
  if (mssgQ==NULL)
    return;
  if (temp->receiver == running->thread_id && (*tid== NULL || temp->sender == *tid)) {
    strcpy(msg, temp->message);
    *len = strlen(msg);
    *tid = temp->sender;
    mssgQ = mssgQ->next;
    return;
  }
  // Go loop through the whole message queue 
  while (temp->next) {
    if (temp->next->receiver == running->thread_id && (*tid==NULL ||temp->sender == *tid)) {
      strcpy(msg, temp->message);
      *len = strlen(msg);
      *tid = temp->next->sender;
      temp->next = temp->next->next;
      return;
    } else {
      temp = temp->next;
    }
  }
}