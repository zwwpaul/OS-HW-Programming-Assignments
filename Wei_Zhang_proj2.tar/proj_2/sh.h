
#include "get_path.h"

int pid;
int sh( int argc, char **argv, char **envp);
char *which(char *command, struct pathelement *pathlist);
char *where(char *command, struct pathelement *pathlist);
void list ( char *dir );
void printpwd( char* pwd);
void printpid();
void killpid (char* pid, char* signal);
void printenv(struct pathelement *pathlist, char * env1, char * env2);
void sig_intHandler(int sig);
void sig_stpHandler(int sig);
#define PROMPTMAX 32
#define MAXARGS 10
