#include <stdio.h>
#include <glob.h>
#include <string.h>
#include <strings.h>
#include <wordexp.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include<errno.h>
#include <signal.h>
#include "sh.h"
#define EXIT 1
#define WHICH 2
#define WHERE 3
#define LIST 4
#define CD 5
#define PWD 6
#define PID 7
#define KILL 8
#define PROMPT 9
#define PRINTENV 10
#define SETENV 11
#define DEFAULT 12

int sh( int argc, char **argv, char **envp )
{
  //watch for CTRL_C
  signal(SIGINT, sig_intHandler);
  //watch for CTRL_Z
  signal(SIGTSTP, sig_stpHandler);
  
  char *prompt = calloc(PROMPTMAX, sizeof(char));
  char *commandline = calloc(MAX_CANON, sizeof(char));
  char *command, *arg, *commandpath, *p, *pwd, *owd;
  char **args = calloc(MAXARGS, sizeof(char*));
  char **args_temp;
  int uid, i, status, argsct, go = 1;
  struct passwd *password_entry;
  char *homedir;
  char *storage;
  const char sp[2] = " ";
  struct pathelement *pathlist;
  int flag;
  glob_t paths;
  size_t ct;
  char** pp;
  char *promptPrefix = calloc(MAX_CANON, sizeof(char));
  promptPrefix="";
  uid = getuid();
  password_entry = getpwuid(uid);               /* get passwd info */
  homedir = password_entry->pw_dir;		/* Home directory to start with*/
   
  if ( (pwd = getcwd(NULL, PATH_MAX+1)) == NULL )
  {
    perror("getcwd");
    exit(2);
  }
  owd = calloc(strlen(pwd) + 1, sizeof(char));
  memcpy(owd, pwd, strlen(pwd));
  prompt[0] = ' '; prompt[1] = '['; prompt[2] = '\0';
  strcat(prompt, pwd);
  prompt[strlen(prompt)+3] = '\0';
  prompt[strlen(prompt)] = ']';
  prompt[strlen(prompt)] = '>';
  prompt[strlen(prompt)] = ' ';

  /* Put PATH into a linked list */
  pathlist = get_path();


  while (go)
  {
    /* print your prompt */
   printf("%s", prompt);
    /* get command line and process */
   while(fgets(commandline, MAX_CANON, stdin) != NULL) {
        commandline[strlen(commandline)-1] = '\0';
        arg = calloc(MAX_CANON, sizeof(char));
        command = calloc(MAX_CANON, sizeof(char));
        args_temp=calloc(MAXARGS,sizeof(char*));
        arg = strtok(commandline, " ");
	if(arg==NULL){
		printf("%s",prompt);
	}else{
        strcpy(command, arg); 
        arg = strtok(NULL, " ");
	
	int count=1;
	/* Get the count of arguements  */	
	count=1;
        args[0] = strtok(commandline, " ");
	while((arg=strtok(NULL, " ")) != NULL){
		args[count] = arg;
		count++;
	}
   	args[count] = NULL;
	argsct = count;

	/* Empty the entire args_temp */
        while (args_temp[count] != NULL) {
           args_temp[count] = NULL;
           count++;
        }
      /* Empty the entire args */
        count = 0;
        while (args[count] != NULL) {
             args[count] = NULL;
             count++;
        }
        count = 0;
        wordexp_t wildcard;
        memset(&wildcard, 0, sizeof(wildcard));
        while (arg != NULL) {
           if (count == 0) {
               if (strcmp(arg, "*") == 0) {
                  wordexp("", &wildcard, 0);
               }
               else {
                     wordexp(arg, &wildcard, 0);
               }
           }
           else {
               if (strcmp(arg, "*") == 0) {
                   wordexp("", &wildcard, WRDE_APPEND);
               }
               else {
                    wordexp(arg, &wildcard, WRDE_APPEND);
               }
           }
           count++;
           arg = strtok(NULL, " ");
      }
      if (count > 0) {
      args = wildcard.we_wordv;
      }
	glob(args[0], GLOB_NOCHECK, NULL, &paths);
	i = 1;	
	while(args[i] != NULL) {
 		glob(args[i], GLOB_APPEND | GLOB_NOCHECK, NULL, &paths);
		i++;
	}
       

    /* check for each built in command and implement */
int flag_t;
if(strcmp(command,"exit")==0){
	flag_t= EXIT;
}else if(strcmp(command,"which")==0){
	flag_t=WHICH;
}else if(strcmp(command,"where")==0){
        flag_t=WHERE;
}else if(strcmp(command,"list")==0){
        flag_t=LIST;
}else if(strcmp(command,"cd")==0){
        flag_t=CD;
}else if(strcmp(command,"pwd")==0){
        flag_t=PWD;
}else if(strcmp(command,"pid")==0){
        flag_t=PID;
}else if(strcmp(command,"prompt")==0){
        flag_t=PROMPT;
}else if(strcmp(command,"kill")==0){
        flag_t=KILL;
}else if(strcmp(command,"printenv")==0){
        flag_t=PRINTENV;
}else if(strcmp(command,"setenv")==0){
        flag_t=SETENV;
}else{
	flag_t=DEFAULT;
}


switch(flag_t){
    /* Exit */
    case EXIT:
        printf("Executing built-in exit!\n");
        exit(0);
        break;
    /* Which */
    case WHICH :
        printf("Executing built-in which!\n");
	count=0;
        while(args[count]!=NULL){
            where(args[count],pathlist);
            count++;
        }
        printf("%s", prompt);
        break;
    /* Where */
    case WHERE:
        printf("Executing built-in where!\n");
        count=0;
        while(args[count]!=NULL){
            where(args[count],pathlist);
            count++;
        }
        printf("%s", prompt);
        break;
    /* List */
    case LIST:
        printf("Executing built-in list!\n");
        count=0;
        if (args[count] == NULL) {
            printf("\nPrinting files in current directory.");
            list(pwd);
        }
        while(args[count]!=NULL){
            printf("Files in %s\n",args[count]);
            list(args[count]);
            count++;
        }
        printf("%s", prompt);
        break;
    /* Cd */
    case CD:
        printf("Executing built-in cd!\n");
        if(args[0]==NULL){
            chdir(homedir);
        }
        else{
            chdir(args[0]);
        }
        if ((pwd = getcwd(NULL, PATH_MAX+1)) == NULL)
        {
            perror("getcwd");
            exit(2);
        }
        snprintf(prompt, PROMPTMAX, "%s%s%s%s", promptPrefix , "[", pwd, "]> ");
        printf("%s", prompt);
        break;
    /* Pwd */
    case PWD:
        printf("Executing built-in pwd!\n");
        printpwd(pwd);
        printf("%s", prompt);
        break;
    /* Pid  */
    case PID:
        printpid();
        printf("%s", prompt);
        break;
    /* Kill  */
    case KILL:
        printf("Executing built-in kill!\n");
        killpid(args[0],args[1]);
        printf("%s", prompt);
        break;
/* Prompt */
    case PROMPT:
        printf("Executing built-in prompt!\n");
        if(argsct >2 ||strlen(command)>PROMPTMAX){
            fprintf(stderr,"Usage: prompt prefix\n");
        }
        else{
            if(args[1]==NULL){
                printf("input prompt prefix: ");
                fgets(prompt, 256, stdin);
                prompt[strlen(prompt) - 1] = ' ';
                prompt[strlen(prompt)] = '\0';
                strcat(prompt, pwd);
            }else{
                strcpy(prompt, args[1]);
                prompt[strlen(args[1])] = ' ';
                prompt[strlen(args[1]) + 1] = '>';
                prompt[strlen(args[1]) + 2] = '\0';
            }
        }
	printf("%s", prompt);
        break;
    /* Printenv */
    case PRINTENV:
        printf("Executing built-in printenv!\n");
        printenv(pathlist,args[0],args[1]);
        printf("%s", prompt);
        break;
   /* Setenv */
    case SETENV:
	printf("Executing built-in setenv!\n");
	if(args[1]==NULL){
	printenv(pathlist,args[0],args[1]);
	}
	else if((args[1]!=NULL)&&(args[2]==NULL)) {
        setenv(args[1], "", 1);
        }
        else {
        setenv(args[1], args[2], 1);
        if(strcmp(args[1], "HOME") == 0) {
        	homedir = getenv("HOME");
        }
        else if(strcmp(args[2], "PATH") == 0) {
                pathlist = get_path();
                    }
                }
         printf("%s",prompt);
	break;
    default:
        if(access(command,F_OK)==0){
            pid_t pid =fork();
            if(pid==-1){
                printf("Fork error!\n");
                return;
            }
            else if (pid==0){
                if(execve(command,args_temp,envp)<0){
                    printf("Could not execute it!");
                }
                exit(0);
            }
            else{
                waitpid(pid,status,0);
                printf("%s",prompt);
            }
        }
        else{
            pid_t pid=fork();
            char * newpath=calloc(MAX_CANON,sizeof(char));
            newpath=which(command,pathlist);
            args_temp[0]=newpath;
            count =0;
            while (args[count] != NULL) {
                args_temp[count+1] = args[count];
                count++;
            }
            if(pid==-1){
                printf("Fork error!\n");
            }
            else if(pid==0){
                if(execve(newpath,args_temp,envp)<0){
                    printf("Could not execute it!\n");
                }
                exit(0);
            }
            else{
                waitpid(pid,&status,0);
                printf("%s",prompt);
            }
            free(newpath);
	}
	break;
}
/* Free allocated memory */
free(arg);
free(args_temp);
free(command);	
}
}
}
/* Free allocated memory */
free(args);
free(commandline);
free(prompt);
  return 0;
} /* sh() */


char *which(char *command, struct pathelement *pathlist )
{
   /* loop through pathlist until finding command and return it.  Return
   NULL when not found. */
int found=0;
struct pathelement *curr =pathlist;
while(curr!=NULL){
	char* path = calloc(MAX_CANON,sizeof(char));
	snprintf(path, MAX_CANON,"%s%s%s",curr->element,"/",command);
	if(access(path,F_OK)==0){
		printf("%s\n",path);
		found=1;
		return path;
	}
	curr=curr->next;
	//free(path);
}
if (found==0){
	fprintf(stderr, "%s: command not found\n", command);
	return NULL;
}
} /* which() */


char *where(char *command, struct pathelement *pathlist )
{
  /* similarly loop through finding all locations of command */
int found=0;
struct pathelement *curr= pathlist;
while(curr!=NULL){
	char* path2 = calloc(MAX_CANON,sizeof(char));
	snprintf(path2, MAX_CANON,"%s%s%s",curr->element,"/",command);
	if(access(path2,F_OK)==0){
                printf("%s\n",path2);
		found=1;
        }
        curr=curr->next;
	//free(path2);
}
if (found==0){
        fprintf(stderr, "%s: command not found\n", command);
        return NULL;
}

} /* where() */



void list ( char *dir )
{
  /* see man page for opendir() and readdir() and print out filenames for
  the directory passed */
DIR* dir_list;
struct dirent *content;
/* Open given directory */
dir_list= opendir(dir);
if(dir_list==NULL){
	perror("The current directory cannot be opened.\n");
}
else{
	printf("%s:\n",dir);
	while((content=readdir(dir_list))!=NULL){
        	printf("%s\n",content->d_name);
	}
}	
closedir(dir_list);
} /* list() */



void printpwd(char *pwd){
	getcwd(pwd,sizeof(pwd));
	printf("\nCurrent Working Directory: %s\n",pwd);
}/* pwd() */

void printpid(){
pid_t pid;
pid=getpid();
if(pid<0){
	perror("Cannot get pid\n");
}else{
	printf("The process id: %d\n",pid);
}
}/* pid() */

void killpid(char *pid, char* signal){
int flag=0;
if(atoi(pid)>0&&atoi(signal)>0){
        flag=kill(atoi(pid),atoi(signal));
        fprintf(stderr,"Process was killed\n");
}else if(atoi(pid)>0 && signal==NULL){
        flag=kill(atoi(pid),SIGTERM);
}else{
 fprintf(stderr, "Error!\n");

}
if(flag==-1){
 perror(pid);
}
}/* killpid() */

void printenv(struct pathelement *pathlist, char * env1, char * env2) {
    if (env1 == NULL) {
        pathlist = pathlist->next;
        while (pathlist->next != NULL) {
            printf("%s\n", pathlist->element);
            pathlist = pathlist->next;
        }
    }
    else if (env2 != NULL) {
        perror("Too many arguments passed\n");
    }
    else {
        printf("%s",getenv(env1));
    }
}/* printenv */

/* handle CTRL-C */
void sig_intHandler(int sig) {
  printf("\n Terminated! %d \n", waitpid(getpid(),NULL,0));
  exit(1);
}

/*handle CTRL-Z*/
void sig_stpHandler(int sig) {
  printf("\n Cannot be terminated using Ctrl+Z \n");
  fflush(stdout);

}

